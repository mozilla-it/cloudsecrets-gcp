# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cloudsecrets', 'cloudsecrets.cli']

package_data = \
{'': ['*']}

install_requires = \
['boto3', 'google-cloud-secret-manager', 'simplejson']

setup_kwargs = {
    'name': 'cloudsecrets',
    'version': '0.0.2',
    'description': 'Python tool for accessing mozilla cloud secrets',
    'long_description': None,
    'author': 'Adam Frank',
    'author_email': 'afrank@mozilla.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.4',
}


setup(**setup_kwargs)
